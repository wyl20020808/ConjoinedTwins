extends RefCounted

# 20 地面单位为一米；双方使用同一个固定步、连接和高度判定。
const Motion = preload("res://scripts/link_motion.gd")
const FINISH := 9000.0
const FORWARD := 120.0
const LATERAL := 130.0
const EDGE := 234.0
const RELATIVE_RANGE := 70.0
const FIXED_STEP := 1.0 / 120.0
const JUMP_SPEED := 110.0
const GRAVITY := 240.0
var a := Node2D.new()
var b := Node2D.new()
var state := "start"
var elapsed := 0.0
var distance := 0.0
var failures := 0
var obstacles: Array[Rect2] = []
var kinds: Array[String] = []
var obstacle_heights: Array[float] = []
var heights := [0.0, 0.0]
var vertical_speed := [0.0, 0.0]
var jump_held := [true, true]
var jump_pending := [false, false]
var reason := ""
var clear_input := true
var accumulator := 0.0

func _init() -> void:
	for row in range(17):
		var y := 620.0 + row * 470.0
		var x := [-145.0, 65.0, -40.0, -145.0, 65.0][row % 5] as float
		obstacles.append(Rect2(x, y, 80, 65))
		kinds.append("energy" if row >= 6 and row % 3 == 0 else "cargo")
		obstacle_heights.append(54.0 if kinds.back() == "energy" else 34.0)
	retry()
	state = "start"

func dispose() -> void:
	a.free()
	b.free()

func reset_input() -> void:
	clear_input = true
	jump_held = [true, true]
	jump_pending = [false, false]
	accumulator = 0.0

func retry(count_failure: bool = false) -> void:
	if count_failure:
		failures += 1
	a.position = Vector2(-42, 0)
	b.position = Vector2(42, 0)
	elapsed = 0.0
	distance = 0.0
	heights = [0.0, 0.0]
	vertical_speed = [0.0, 0.0]
	reason = ""
	state = "running"
	reset_input()

func pause() -> void:
	if state == "running":
		state = "paused"
	elif state == "paused":
		state = "running"
	reset_input()

func progress() -> float:
	return minf(a.position.y, b.position.y)

func section() -> int:
	return clampi(int(progress() / 3000.0), 0, 2)

func step(delta: float, input_a: Vector2 = Vector2.ZERO, input_b: Vector2 = Vector2.ZERO, jump_a: bool = false, jump_b: bool = false) -> void:
	if state != "running":
		return
	if clear_input:
		input_a = Vector2.ZERO
		input_b = Vector2.ZERO
		jump_held = [jump_a, jump_b]
		clear_input = false
	else:
		var pressed := [jump_a, jump_b]
		for i in range(2):
			if pressed[i] and not jump_held[i] and heights[i] == 0.0:
				jump_pending[i] = true
			jump_held[i] = pressed[i]
	accumulator += clampf(delta, 0, 0.25)
	while accumulator + 0.0000001 >= FIXED_STEP and state == "running":
		accumulator -= FIXED_STEP
		fixed_step(input_a.limit_length(), input_b.limit_length())

func fixed_step(input_a: Vector2, input_b: Vector2) -> void:
	elapsed += FIXED_STEP
	distance = minf(FINISH, distance + FORWARD * FIXED_STEP)
	# 每子步地面位移小于碰撞半径，跳跃底部高度也做连续区间检测。
	for i in range(2):
		if jump_pending[i] and heights[i] == 0.0:
			vertical_speed[i] = JUMP_SPEED
		jump_pending[i] = false
	var count := 3
	var dt := FIXED_STEP / count
	for substep in range(count):
		var old_heights := heights.duplicate()
		for i in range(2):
			if heights[i] > 0 or vertical_speed[i] > 0:
				heights[i] = maxf(0, heights[i] + vertical_speed[i] * dt - GRAVITY * dt * dt * 0.5)
				vertical_speed[i] -= GRAVITY * dt
				if heights[i] == 0:
					vertical_speed[i] = 0.0
		var pa := a.position
		var pb := b.position
		var base := Vector2(0, FORWARD * dt)
		var ca := bounded(pa + base + input_a * LATERAL * dt)
		var cb := bounded(pb + base + input_b * LATERAL * dt)
		if ca.distance_to(cb) > Motion.LIMIT:
			var ba := bounded(pa + base)
			var bb := bounded(pb + base)
			var low := 0.0
			var high := 1.0
			for iteration in range(20):
				var t := (low + high) * 0.5
				if ba.lerp(ca, t).distance_to(bb.lerp(cb, t)) <= Motion.LIMIT:
					low = t
				else:
					high = t
			ca = ba.lerp(ca, low)
			cb = bb.lerp(cb, low)
		a.position = ca
		b.position = cb
		for index in range(obstacles.size()):
			var danger := obstacles[index].grow(Motion.RADIUS)
			for i in range(2):
				var from: Vector2 = pa if i == 0 else pb
				var to: Vector2 = ca if i == 0 else cb
				if minf(old_heights[i], heights[i]) <= obstacle_heights[index] and segment_hits(from, to, danger):
					state = "failed"
					reason = "%02d 触碰%s，两人共同重试" % [i + 1, "能量屏障" if kinds[index] == "energy" else "高货箱（请绕行）"]
					reset_input()
					return
	if a.position.y >= FINISH and b.position.y >= FINISH:
		state = "finished"
		reset_input()

func bounded(p: Vector2) -> Vector2:
	return Vector2(clampf(p.x, -EDGE, EDGE), clampf(p.y, maxf(0, distance - RELATIVE_RANGE), minf(FINISH, distance + RELATIVE_RANGE)))

static func segment_hits(from: Vector2, to: Vector2, rect: Rect2) -> bool:
	var low := 0.0
	var high := 1.0
	for axis in range(2):
		var d := to[axis] - from[axis]
		if absf(d) < 0.000001:
			if from[axis] < rect.position[axis] or from[axis] > rect.end[axis]:
				return false
		else:
			var first := (rect.position[axis] - from[axis]) / d
			var last := (rect.end[axis] - from[axis]) / d
			low = maxf(low, minf(first, last))
			high = minf(high, maxf(first, last))
			if low > high:
				return false
	return true
