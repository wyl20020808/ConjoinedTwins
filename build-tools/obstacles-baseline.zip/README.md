# 共生连线 · 双人归航 Demo

两台机甲沿未来工业港道路自动前进，在同一键盘上合作避障。生产入口仅提供本地双人，无 AI 控制、模式切换或自动接管。固定纵深镜头，不旋转、不晃动、不突然变焦。

**Windows 启动：双击 `启动归航Demo.cmd`。** 或用 Godot 4.7.1 打开 `project.godot`，运行 `scenes/road_demo.tscn`。Agent 不自动打开游戏。

## 操作与规则

| 按键 | 行为 |
| --- | --- |
| WASD | 青色 01 四向移动；W 向前、S 向后 |
| 空格 | 01 跳跃 |
| 方向键 | 橙色 02 四向移动；上向前、下向后 |
| 回车 | 02 跳跃 |
| 空格 / 回车 / 开始按钮 | 开始页或失败页启动共同出发，不附带跳跃 |
| Esc | 暂停 / 继续 |
| R | 两人共同回到起点 |

没有趴下、爬行或二段跳。跳跃按下触发，长按不会连续起跳。开始、暂停恢复及重试会屏蔽仍按住的旧输入，请松开后重新按下。

道路自动推进 6 米/秒，四向手动移动速度 6.5 米/秒，斜向归一化。两人分别可在自动推进中心前后 ±3.5 米范围内调节，角色中心横向边界 ±11.7 米（原 ±7.8 米的 1.5 倍）。实际路面宽 24.6 米，侧边设施同步外移。路线仍为三个区段共 450 米，约 75 秒；本任务没有实现无限道路、新障碍类别或难度选项。

双方地面中心最大间距 11 米，包含前后差；碰撞半径 0.6 米。接近 85% 连接长度时连线变金色。跳跃不强迫队友起跳，不增加地面连接长度。跳跃初速 5.5 米/秒、重力 12 米/秒²，最高约 1.26 米。当前高货箱 1.7 米、能量屏障 2.7 米，须绕行，不能靠跳跃穿越。任意一人触碰危险共同失败；重试恢复双方合法地面状态。

George / Leela 复用已有 CC0 骨骼资源，播放 Idle、Run、Jump、HitRecieve_1、Death 及基础过渡。阴影保持在地面并随高度缩小，连线三维端点跟随角色。地面规则与显示分离，20 地面单位为一米。

## 验证与证据

双击 `验证归航Demo.cmd`，或执行：

```powershell
& "D:/Tools/Godot/4.7.1/Godot_v4.7.1-stable_win64_console.exe" --headless --path "D:/ConjoinedTwins" --script res://tests/duo_headless.gd --log-file "D:/ConjoinedTwins/tests/duo-headless.log"
```

测试实例化生产场景；结果为 `tests/duo-result.json`。检查独立移动、归一化、边界、前后连接、跳跃触发、高度碰撞、暂停/恢复、共同重试、动画轨道与生产双人通关路线。低障碍碰撞使用明确标识的夹具；合成键盘事件只验证输入映射，不代表真实键盘多键并按能力。

本轮记录见 [双人移动验证报告](docs/DUO_MOVEMENT_REPORT.md)。执行者自测、决策者审查和用户试玩分别记录；真实设备输入、双人手感和晕动体验仍待真人试玩。可见 GUI 验收在 work 模式下延后。

## 历史与恢复

修改前生产文件、说明和机甲资产保存在 `build-tools/duo-movement-baseline.zip`。原白盒、旧验证脚本、历史截图与旧 Mac 包均保留；`tests/road_headless.gd` 和 `tests/capture_road.gd` 是旧 AI 玩法证据入口，不适用于当前生产 API，不将旧结果当作本轮通过证据。

现有 `builds/macos/ConjoinedTwins-macOS-universal.zip` 为上轮包，不包含本轮双人改动；本任务未重新导出 Mac 包。[Mac 测试说明](docs/MAC_TEST.md) · [既有导出流程](docs/MACOS_EXPORT_WORKFLOW.md)

[资产来源 / CC0 许可](ASSET_SOURCES.md) · [历史恢复清单](docs/ART_DEMO_RECOVERY.md)
