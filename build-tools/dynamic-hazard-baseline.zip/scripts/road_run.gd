extends RefCounted

# 20 地面单位为一米；双方使用同一个固定步、连接和高度判定。
const Motion = preload("res://scripts/link_motion.gd")
const FINISH := 9000.0
const FORWARD := 120.0
const LATERAL := 130.0
const EDGE := 234.0
const RELATIVE_RANGE := 70.0
const FIXED_STEP := 1.0 / 120.0
const JUMP_SPEED := 110.0
const GRAVITY := 240.0
const BODY_HEIGHT := 58.0
var a := Node2D.new()
var b := Node2D.new()
var state := "start"
var elapsed := 0.0
var distance := 0.0
var failures := 0
var obstacles: Array[Rect2] = []
var kinds: Array[String] = []
var obstacle_heights: Array[float] = []
var hazard_specs: Array[Dictionary] = []
var actions := ["Idle", "Idle"]
var land_time := [0.0, 0.0]
var move_directions := [Vector2.ZERO, Vector2.ZERO]
var heights := [0.0, 0.0]
var vertical_speed := [0.0, 0.0]
var jump_held := [true, true]
var jump_pending := [false, false]
var reason := ""
var clear_input := true
var accumulator := 0.0

func _init() -> void:
	for row in range(17):
		var y := 620.0 + row * 470.0
		var x := [-145.0, 65.0, -40.0, -145.0, 65.0][row % 5] as float
		obstacles.append(Rect2(x, y, 80, 65))
		var kind: String = ["cargo", "rail", "spikes", "active_spikes", "scanner", "fly_low", "fly_body", "fly_tall"][row % 8]
		kinds.append(kind)
		var top: float = {"cargo": 34.0, "rail": 12.0, "spikes": 10.0, "active_spikes": 16.0, "scanner": 50.0, "fly_low": 10.0, "fly_body": 38.0, "fly_tall": 85.0}[kind]
		obstacle_heights.append(top)
		if kind != "cargo": obstacles[row].size.y = 12.0 if kind in ["rail", "spikes", "active_spikes"] else 24.0
		hazard_specs.append({"bottom": 26.0 if kind == "scanner" else (18.0 if kind == "fly_body" else 0.0), "period": 4.0, "warning": 1.0, "active": 1.5, "phase": 0.0, "velocity": Vector2(-320, 0) if kind.begins_with("fly_") else Vector2.ZERO, "flight_duration": 1.0, "trigger": (y - 120.0) / FORWARD})
	retry()
	state = "start"

func dispose() -> void:
	a.free()
	b.free()

func reset_input() -> void:
	clear_input = true
	jump_held = [true, true]
	jump_pending = [false, false]
	accumulator = 0.0

func retry(count_failure: bool = false) -> void:
	if count_failure:
		failures += 1
	a.position = Vector2(-42, 0)
	b.position = Vector2(42, 0)
	elapsed = 0.0
	distance = 0.0
	heights = [0.0, 0.0]
	vertical_speed = [0.0, 0.0]
	actions = ["Idle", "Idle"]
	land_time = [0.0, 0.0]
	move_directions = [Vector2.ZERO, Vector2.ZERO]
	reason = ""
	state = "running"
	reset_input()

func pause() -> void:
	if state == "running":
		state = "paused"
	elif state == "paused":
		state = "running"
	reset_input()

func progress() -> float:
	return minf(a.position.y, b.position.y)

func section() -> int:
	return clampi(int(progress() / 3000.0), 0, 2)

func step(delta: float, input_a: Vector2 = Vector2.ZERO, input_b: Vector2 = Vector2.ZERO, jump_a: bool = false, jump_b: bool = false) -> void:
	if state != "running":
		return
	if clear_input:
		input_a = Vector2.ZERO
		input_b = Vector2.ZERO
		jump_held = [jump_a, jump_b]
		clear_input = false
	else:
		var pressed := [jump_a, jump_b]
		for i in range(2):
			if pressed[i] and not jump_held[i] and heights[i] == 0.0:
				jump_pending[i] = true
			jump_held[i] = pressed[i]
	accumulator += clampf(delta, 0, 0.25)
	while accumulator + 0.0000001 >= FIXED_STEP and state == "running":
		accumulator -= FIXED_STEP
		fixed_step(input_a.limit_length(), input_b.limit_length())

func fixed_step(input_a: Vector2, input_b: Vector2) -> void:
	move_directions = [input_a, input_b]
	elapsed += FIXED_STEP
	distance = minf(FINISH, distance + FORWARD * FIXED_STEP)
	# 每子步地面位移小于碰撞半径，跳跃底部高度也做连续区间检测。
	for i in range(2):
		if jump_pending[i] and heights[i] == 0.0:
			vertical_speed[i] = JUMP_SPEED
		jump_pending[i] = false
	var count := 3
	var dt := FIXED_STEP / count
	for substep in range(count):
		var time_end := elapsed - FIXED_STEP + (substep + 1) * dt
		var time_start := time_end - dt
		var old_heights := heights.duplicate()
		for i in range(2):
			if heights[i] > 0 or vertical_speed[i] > 0:
				heights[i] = maxf(0, heights[i] + vertical_speed[i] * dt - GRAVITY * dt * dt * 0.5)
				vertical_speed[i] -= GRAVITY * dt
				if heights[i] == 0:
					vertical_speed[i] = 0.0
					land_time[i] = 0.12
			land_time[i] = maxf(0, land_time[i] - dt)
			actions[i] = ("Takeoff" if vertical_speed[i] > 70 else "Air") if heights[i] > 0 else ("Land" if land_time[i] > 0 else "Run")
		var pa := a.position
		var pb := b.position
		var base := Vector2(0, FORWARD * dt)
		var ca := bounded(pa + base + input_a * LATERAL * dt)
		var cb := bounded(pb + base + input_b * LATERAL * dt)
		if ca.distance_to(cb) > Motion.LIMIT:
			var ba := bounded(pa + base)
			var bb := bounded(pb + base)
			var low := 0.0
			var high := 1.0
			for iteration in range(20):
				var t := (low + high) * 0.5
				if ba.lerp(ca, t).distance_to(bb.lerp(cb, t)) <= Motion.LIMIT:
					low = t
				else:
					high = t
			ca = ba.lerp(ca, low)
			cb = bb.lerp(cb, low)
		a.position = ca
		b.position = cb
		for index in range(obstacles.size()):
			var first := hazard_sample(index, time_start)
			var last := hazard_sample(index, time_end)
			if not first.active and not last.active: continue
			for i in range(2):
				var from: Vector2 = pa if i == 0 else pb
				var to: Vector2 = ca if i == 0 else cb
				var motion: Vector2 = last.rect.position - first.rect.position
				var bottom: float = minf(first.bottom, last.bottom)
				var top: float = maxf(first.top, last.top)
				if swept_body_hits(from, to - motion, old_heights[i], heights[i], first.rect.grow(Motion.RADIUS), bottom, top):
					state = "failed"
					actions = ["Hit", "Hit"]
					reason = "%02d 命中%s，两人共同重试" % [i + 1, hazard_name(kinds[index])]
					reset_input()
					return
	if a.position.y >= FINISH and b.position.y >= FINISH:
		state = "finished"
		reset_input()
		actions = ["Idle", "Idle"]

static func hazard_name(kind: String) -> String:
	return {"cargo": "高货箱：左右绕行", "rail": "低栏：跳跃或绕行", "spikes": "固定地刺：跳跃或绕行", "active_spikes": "活动地刺：伸出期间跳跃或绕行", "scanner": "高位扫描束：绕行或等待安全时窗", "fly_low": "低位飞行物：跳跃或绕行", "fly_body": "身体高度飞行物：四向避让", "fly_tall": "高大飞行物：四向避让"}.get(kind, "能量屏障")

func hazard_sample(index: int, time: float) -> Dictionary:
	var spec: Dictionary = hazard_specs[index] if index < hazard_specs.size() else {}
	var kind: String = kinds[index]
	var rect: Rect2 = obstacles[index]
	var bottom: float = spec.get("bottom", 0.0)
	var top: float = obstacle_heights[index]
	var active := true
	var warning := false
	var stage := "active"
	if kind in ["active_spikes", "scanner"]:
		var cycle := fposmod(time + float(spec.get("phase", 0)), float(spec.get("period", 4)))
		var warn: float = spec.get("warning", 1.0)
		var duration: float = spec.get("active", 1.5)
		warning = cycle < warn
		active = cycle >= warn and cycle < warn + duration
		stage = "warning" if warning else ("active" if active else "safe")
		if kind == "active_spikes":
			var extension := clampf((cycle - warn) / 0.25, 0, 1) * clampf((warn + duration - cycle) / 0.25, 0, 1)
			top *= extension
			stage = "extend" if active and cycle < warn + 0.25 else ("retract" if active and cycle > warn + duration - 0.25 else stage)
	if kind.begins_with("fly_"):
		var trigger: float = spec.get("trigger", 0)
		var duration: float = spec.get("flight_duration", 1)
		var velocity: Vector2 = spec.get("velocity", Vector2.ZERO)
		warning = time >= trigger - 1.0 and time < trigger
		active = time >= trigger and time <= trigger + duration
		rect.position += velocity * clampf(time - trigger, 0, duration)
		stage = "warning" if warning else ("active" if active else "safe")
	return {"rect": rect, "bottom": bottom, "top": top, "active": active, "warning": warning, "stage": stage}

# 将地面扫掠与高度区间在同一时间参数上求交，避免高速穿越和落地漏判。
static func swept_body_hits(from: Vector2, to: Vector2, h0: float, h1: float, rect: Rect2, bottom: float, top: float) -> bool:
	var origin := Vector3(from.x, from.y, h0)
	var end := Vector3(to.x, to.y, h1)
	var minimum := Vector3(rect.position.x, rect.position.y, bottom - BODY_HEIGHT)
	var maximum := Vector3(rect.end.x, rect.end.y, top)
	var low := 0.0
	var high := 1.0
	for axis in range(3):
		var d := end[axis] - origin[axis]
		if absf(d) < 0.000001:
			if origin[axis] < minimum[axis] or origin[axis] > maximum[axis]: return false
		else:
			var first := (minimum[axis] - origin[axis]) / d
			var last := (maximum[axis] - origin[axis]) / d
			low = maxf(low, minf(first, last))
			high = minf(high, maxf(first, last))
			if low > high: return false
	return true

func bounded(p: Vector2) -> Vector2:
	return Vector2(clampf(p.x, -EDGE, EDGE), clampf(p.y, maxf(0, distance - RELATIVE_RANGE), minf(FINISH, distance + RELATIVE_RANGE)))

static func segment_hits(from: Vector2, to: Vector2, rect: Rect2) -> bool:
	var low := 0.0
	var high := 1.0
	for axis in range(2):
		var d := to[axis] - from[axis]
		if absf(d) < 0.000001:
			if from[axis] < rect.position[axis] or from[axis] > rect.end[axis]:
				return false
		else:
			var first := (rect.position[axis] - from[axis]) / d
			var last := (rect.end[axis] - from[axis]) / d
			low = maxf(low, minf(first, last))
			high = minf(high, maxf(first, last))
			if low > high:
				return false
	return true
