# t02 障碍与动作反馈：决策者审查

日期：2026-10-12。任务：`t02-obstacles-and-action-feedback`。结论：返工。

## 已验证部分

核对生产危险定义、固定步碰撞、危险显示及动作反馈代码。六类危险与飞行物三种高度均已接入当前 450 米路线；双人规则及固定镜头保留，无低姿态动作或拾取逻辑。检查 `build-tools/obstacles-baseline.zip`，5 个条目，CRC 检查无错误。此次不声明全量项目变更已经核对。

独立复跑执行者检查，保留原断言并将证据输出到不同文件：

- `tests/decision_duo_t02_review.gd`：40/40 通过，退出码 0；结果 `tests/decision-duo-t02-result.json`，日志 `tests/decision-duo-t02-headless.log`。
- `tests/decision_obstacles_t02_review.gd`：50/50 通过，退出码 0；结果 `tests/decision-obstacles-t02-result.json`，日志 `tests/decision-obstacles-t02-headless.log`。

以上命令均使用 Godot `4.7.1.stable.official.a13da4feb`、`--headless --path D:/ConjoinedTwins --script res://tests/<脚本>`，没有桌面输入或 GUI 操作。首次启动复跑时副本写入进程尚未完成，得到脚本不存在错误；等待该进程正常退出后重新运行，以上为实际完成的结果。

实际打开查看 `docs/screenshots/t02-spikes-active.png`、`t02-fly_body.png`、`t02-scanner.png`。地刺尖锥、身体高度飞行物、扫描束安全状态与文字可辨，宽道路、双方角色、地面阴影与连线仍可读。截图审查不代表实体键盘、实时动画或双人手感验收。

## 必须修复：动态刺高导致提前致命

`scripts/road_run.gd` 的 `fixed_step()` 取子步首尾危险高度的最大值作为整个子步的静态上界，再调用 `swept_body_hits()`。后者虽然让角色平面与高度共用时间参数，却没有同步危险高度的变化，因此在地刺伸出时会把未来的高度提前应用于接触。

独立复现脚本：`tests/decision_dynamic_hazard_probe.gd`。实际运行命令：

```powershell
rtk proxy "D:/Tools/Godot/4.7.1/Godot_v4.7.1-stable_win64_console.exe" --headless --path D:/ConjoinedTwins --script res://tests/decision_dynamic_hazard_probe.gd --log-file D:/ConjoinedTwins/tests/decision-dynamic-hazard-probe.log
```

退出码 1，结果为 `tests/decision-dynamic-hazard-probe.json`。该明确夹具保留生产跳跃初速 110、重力 240、自动推进速度 120、活动刺最大高度 16、4 秒周期及 0.25 秒伸出时间；仅将一组活动刺移到 `Rect2(-55, 149.333333333333, 26, 8)`，玩家一在 1.05 秒按下跳跃。双方仍通过正常输入及生产固定步更新，没有修改角色位置、关闭约束或直接设置高度。

按半径 12 扩张后的平面接触时间为约 1.144444 至 1.411111 秒。角色跳跃高度为 `110*(t-1.05)-120*(t-1.05)^2`；伸出段刺高为 `64*(t-1)`，完整伸出后为 16。整个平面接触区间角色底部都高于真实刺顶，最小净空约 0.074074 地面单位，故本夹具应合法通过。实际却在物理时间约 1.147224 秒共同失败：角色高度 9.560185，真实刺高 9.422347，净空仍为正值 0.137838。

这不是实体键盘或可见 GUI 缺证据，而是实际生产碰撞的独立可复现错误，阻止本任务通过。

## 返工要求

按同一时间参数处理角色运动、动态危险运动及底顶高度；对激活、失活、伸出、完整伸出和回落边界按需分段处理，不能以全子步高度包络替代实际时间判定。保留上述复现及预期合法通过的断言，修复后该脚本应退出 0；补充双方伸出/回落接触边界检查，并复跑既有双人回归、高速扫掠及动态周期检查。不要修改可信断言、扩大高度容差或改变本夹具输入来掩盖误判。

本次未修改生产实现。Controller 独立测试未运行，配置为 `tests=[]`；执行者记录的可见 GUI `deferred_by_work_mode` 和真人试玩边界继续保留。没有本轮 Mac 导出、提交、合并、推送或公开发布；所有审查进程均已退出。
