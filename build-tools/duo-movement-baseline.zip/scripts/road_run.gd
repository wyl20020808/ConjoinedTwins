extends RefCounted

# 所有玩法使用地面单位；显示层以 20 地面单位换算 1 米。
const Motion = preload("res://scripts/link_motion.gd")
const FINISH := 9000.0
const FORWARD := 120.0
const LATERAL := 130.0
const EDGE := 156.0
var a := Node2D.new()
var b := Node2D.new()
var state := "start"
var local_duo := false
var elapsed := 0.0
var failures := 0
var obstacles: Array[Rect2] = []
var kinds: Array[String] = []
var reason := ""
var clear_input := false

func _init() -> void:
	# 三段连续道路；每组保留至少两名机器人可以共享的安全走廊。
	for row in range(17):
		var y := 620.0 + row * 470.0
		var x := [-145.0, 65.0, -40.0, -145.0, 65.0][row % 5] as float
		var width := 80.0 if row % 5 != 2 else 80.0
		obstacles.append(Rect2(x, y, width, 65))
		kinds.append("energy" if row >= 6 and row % 3 == 0 else "cargo")
	retry(false)
	state = "start"

func dispose() -> void:
	a.free()
	b.free()

func retry(count_failure: bool = false) -> void:
	if count_failure:
		failures += 1
	a.position = Vector2(-42, 0)
	b.position = Vector2(42, 0)
	elapsed = 0.0
	reason = ""
	state = "running"
	clear_input = true

func set_duo(value: bool) -> void:
	local_duo = value
	clear_input = true

func pause() -> void:
	if state == "running":
		state = "paused"
	elif state == "paused":
		state = "running"
		clear_input = true

func progress() -> float:
	return minf(a.position.y, b.position.y)

func section() -> int:
	return mini(2, int(progress() / 3000.0))

func safe_target(p: Vector2, preferred: float) -> float:
	var best := clampf(preferred, -EDGE, EDGE)
	var score := INF
	for candidate: float in [-125.0, -95.0, -65.0, 0.0, 65.0, 95.0, 125.0]:
		var cost := absf(candidate - preferred) + absf(candidate - p.x) * 0.25
		for obstacle in obstacles:
			if obstacle.end.y >= p.y - 12 and obstacle.position.y < p.y + 310:
				if candidate > obstacle.position.x - 22 and candidate < obstacle.end.x + 22:
					cost += 10000
				# 不在障碍内部横穿，提前换到安全走廊。
				if p.y > obstacle.position.y - 28 and p.y < obstacle.end.y + 28:
					if minf(p.x, candidate) < obstacle.end.x + 12 and maxf(p.x, candidate) > obstacle.position.x - 12:
						cost += 20000
		if cost < score:
			score = cost
			best = candidate
	return best

func steering(p: Vector2, target: float) -> float:
	return clampf((target - p.x) / 24.0, -1.0, 1.0)

func ai_input() -> float:
	var preferred := a.position.x + (70.0 if a.position.x <= 0 else -70.0)
	var target := safe_target(b.position, preferred)
	return steering(b.position, target)

func step(delta: float, input_a: float, input_b: float = 0.0) -> void:
	if state != "running":
		return
	if clear_input:
		input_a = 0.0
		input_b = 0.0
		clear_input = false
	elapsed += delta
	var second := input_b if local_duo else ai_input()
	var walls: Array = [Rect2(-1000, -100, 832, FINISH + 300), Rect2(168, -100, 832, FINISH + 300)]
	walls.append_array(obstacles)
	var previous_a := a.position
	var previous_b := b.position
	var da := Vector2(clampf(input_a, -1, 1) * LATERAL, FORWARD if a.position.y < FINISH else 0.0)
	var db := Vector2(clampf(second, -1, 1) * LATERAL, FORWARD if b.position.y < FINISH else 0.0)
	Motion.advance(a, b, da / Motion.SPEED, db / Motion.SPEED, delta, walls)
	for obstacle in obstacles:
		for pair in [[previous_a, a.position, da], [previous_b, b.position, db]]:
			if obstacle.grow(Motion.RADIUS + 0.02).has_point(pair[1]) or obstacle.grow(Motion.RADIUS).has_point(pair[0] + pair[2] * delta):
				state = "failed"
				reason = "任一机甲触碰货箱或能量屏障，两人共同重试"
				return
	if a.position.y >= FINISH and b.position.y >= FINISH:
		state = "finished"
