# 共生连线 · 归航 Demo

两台机甲沿未来工业港的道路自动前进，用长度有限的能量线共同穿过货箱与能量屏障。固定镜头朝向和俯角，道路收向远方，玩家只控制横向位置。默认单人加离线确定性 AI，无联网、在线模型或 API Key。

**Windows 启动：双击 `启动归航Demo.cmd`。** 或使用 Godot 4.7.1 打开 `project.godot` 运行默认场景 `scenes/road_demo.tscn`。不会自动打开游戏，首次导入会生成 `.godot/` 缓存。

**Mac 独立测试包：** `builds/macos/ConjoinedTwins-macOS-universal.zip`，包含 Universal 2 应用，无需安装 Godot。操作、系统要求及 Gatekeeper 指引见 [Mac 测试说明](docs/MAC_TEST.md)；本轮哈希和验证见 [Demo 验证报告](docs/ART_DEMO_REPORT.md)。

![生产场景真实运行画面](docs/screenshots/03-homeward.png)

## 操作与规则

| 按键 / 按钮 | 行为 |
| --- | --- |
| Enter / Space / 开始按钮 | 开始；结束后再次归航 |
| A / D | 控制青色 01 左右滑行 |
| 左 / 右方向键 | 单人时也控制 01；本地双人时控制橙色 02 |
| Esc | 暂停 / 继续，暂停冻结双方位置与计时 |
| R | 两人共同回到起点重新归航 |
| Tab / 菜单模式按钮 | 单人 + 离线 AI / 本地双人；切换保留双方位置 |

三个连续区段共 450 米，安全起步、能量通道、协同归航。自动前进 6 米/秒，横向速度最多 6.5 米/秒；正常无失败路线约 75 秒。机甲滑行表现使用自然静态姿态，本轮没有跑步动画。

双方中心最大间距 11 米，碰撞半径 0.6 米。接近 85% 长度时连线变金色；保持靠近可解除张紧。相同移动、碰撞、危险和连接代码用于人类与 AI。橙色队友按前方障碍选择安全走廊，仍受距离约束，玩家须主动避障。碰撞货箱或橙色屏障会共同失败，显示重试页；双方抵达终点才完成。没有鼠标地面指令，屏幕坐标不会直接参与碰撞。

镜头固定，不旋转、不晃动、不突然变焦。地面单位与显示比例分离：20 地面单位换算 1 米，HUD、障碍模型和连线使用相同换算。视角舒适性与实际手感仍待真人试玩。

## 验证与结构

双击 `验证归航Demo.cmd`，或在 PowerShell 执行：

```powershell
& "D:/Tools/Godot/4.7.1/Godot_v4.7.1-stable_win64_console.exe" --headless --path "D:/ConjoinedTwins" --script res://tests/road_headless.gd --log-file "D:/ConjoinedTwins/tests/road-headless.log"
```

`road_run.gd` 是固定步的生产规则与离线 AI，复用原 `link_motion.gd` 约束/碰撞；`road_demo.gd` 管理固定镜头、资产、灯光和 UI。新测试使用实际生产场景和正常横向输入完成路线，结果为 `tests/road_result.json`；不会设置通关标记、关闭约束或瞬移通关。终点条件的单独夹具明确标注，不作为通关路线证据。

真实生产画面截图为 `docs/screenshots/`，包括三区段、开始、暂停、结束和终点接近画面；由任务独占隐藏渲染取得，不操作用户桌面。执行者自测与决策者验收分别记录，见 [本轮报告](docs/ART_DEMO_REPORT.md) 和 [美术自查](docs/ART_DEMO_VISUAL_REVIEW.md)。Mac 实机、真实输入、难度和晕动体验待用户试玩。

[资产来源 / CC0 许可](ASSET_SOURCES.md) · [恢复清单](docs/ART_DEMO_RECOVERY.md) · [既有 Mac 导出流程](docs/MACOS_EXPORT_WORKFLOW.md)

## 历史白盒

旧六份生产脚本、`scenes/main.tscn`、旧测试和旧报告均保留。`启动白盒.cmd` 是明确的历史调试入口；`验证白盒.cmd` 是旧玩法验证入口。旧 65 项结果只证明当次白盒，不代表本轮新玩法回归。本轮不删改旧断言，不将历史结果重复当作新证据。恢复 ZIP 和旧 Mac 包存放位置见恢复清单；新 Mac 包排除历史白盒、测试、文档、下载源包和制作工具。
