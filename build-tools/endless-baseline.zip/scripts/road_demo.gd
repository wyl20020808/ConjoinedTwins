extends Node3D

const Run = preload("res://scripts/road_run.gd")
const SCALE := 20.0
var run = Run.new()
var road := Node3D.new()
var camera := Camera3D.new()
var robots: Array[Node3D] = []
var cable := MeshInstance3D.new()
var hud: Label
var distance_label: Label
var panel: PanelContainer
var title: Label
var subtitle: Label
var primary: Button
var animation_players: Array[AnimationPlayer] = []
var shadows: Array[MeshInstance3D] = []
var blocked_keys: Array[int] = []
var failed_animation_started := [false, false]
var hazard_views: Array[Node3D] = []
var last_actions := ["Idle", "Idle"]
const MOVE_KEYS := [KEY_A, KEY_D, KEY_W, KEY_S, KEY_LEFT, KEY_RIGHT, KEY_UP, KEY_DOWN, KEY_SPACE, KEY_ENTER]
var progress_bar: ColorRect
var progress_fill: ColorRect
var scenery: Array[Node3D] = []
var materials := {}
var cable_material: StandardMaterial3D
var capture_mode := false

func material(name: String, color: Color, emission: float = 0.0) -> StandardMaterial3D:
	if materials.has(name):
		return materials[name]
	var m := StandardMaterial3D.new()
	m.albedo_color = color
	m.roughness = 0.75
	if emission > 0:
		m.emission_enabled = true
		m.emission = color
		m.emission_energy_multiplier = emission
	materials[name] = m
	return m

func box(parent: Node3D, pos: Vector3, size: Vector3, mat: Material) -> MeshInstance3D:
	var instance := MeshInstance3D.new()
	var mesh := BoxMesh.new()
	mesh.size = size
	instance.mesh = mesh
	instance.material_override = mat
	instance.position = pos
	parent.add_child(instance)
	return instance

func model(path: String, parent: Node3D, pos: Vector3, height: float, yaw: float = 0.0, width_limit: float = 8.0) -> Node3D:
	var instance: Node3D = load(path).instantiate()
	parent.add_child(instance)
	var bounds := model_bounds(instance, instance)
	var factor := height / maxf(bounds.size.y, 0.01)
	if "industrial" in path:
		factor = minf(factor, width_limit / maxf(bounds.size.x, bounds.size.z))
	instance.scale = Vector3.ONE * factor
	instance.position = pos - Vector3(bounds.get_center().x, bounds.position.y, bounds.get_center().z) * factor
	instance.rotation.y = yaw
	if "industrial" in path:
		apply_industrial_palette(instance)
	return instance

func apply_industrial_palette(node: Node) -> void:
	if node is MeshInstance3D:
		for surface in range(node.mesh.get_surface_count()):
			var original = node.mesh.surface_get_material(surface)
			if original is StandardMaterial3D:
				var mat: StandardMaterial3D = original.duplicate()
				mat.albedo_texture = load("res://assets/industrial/Textures/colormap.png")
				mat.albedo_color = Color("92a6b0")
				mat.roughness = 0.85
				node.set_surface_override_material(surface, mat)
	for child in node.get_children():
		apply_industrial_palette(child)

func model_bounds(root: Node3D, node: Node) -> AABB:
	var bounds := AABB()
	if node is MeshInstance3D:
		bounds = (root.global_transform.affine_inverse() * node.global_transform) * node.get_aabb()
	for child in node.get_children():
		var sub := model_bounds(root, child)
		if sub.size != Vector3.ZERO:
			bounds = sub if bounds.size == Vector3.ZERO else bounds.merge(sub)
	return bounds

func register_animation(node: Node) -> void:
	if node is AnimationPlayer:
		animation_players.append(node)
		for name in node.get_animation_list():
			if name.ends_with("Idle") or name.ends_with("Run"):
				node.get_animation(name).loop_mode = Animation.LOOP_LINEAR
		node.animation_finished.connect(func(name):
			if name.ends_with("HitRecieve_1") and run.state == "failed":
				play_action(node, "Death"))
	for child in node.get_children():
		register_animation(child)

func play_action(player: AnimationPlayer, action: String) -> void:
	for name in player.get_animation_list():
		if name.ends_with(action):
			if player.current_animation != name:
				player.play(name, 0.1)
			return

func _ready() -> void:
	capture_mode = "--capture-demo" in OS.get_cmdline_user_args()
	add_child(road)
	build_lighting()
	build_road()
	build_robots()
	build_ui()
	sync_view()

func _exit_tree() -> void:
	run.dispose()

func build_lighting() -> void:
	var world := WorldEnvironment.new()
	var env := Environment.new()
	env.background_mode = Environment.BG_SKY
	var sky := Sky.new()
	var sky_mat := ProceduralSkyMaterial.new()
	sky_mat.sky_top_color = Color("193247")
	sky_mat.sky_horizon_color = Color("9bb1b6")
	sky_mat.ground_horizon_color = Color("9bb1b6")
	sky_mat.ground_bottom_color = Color("14222c")
	sky.sky_material = sky_mat
	env.sky = sky
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color("a3bdd2")
	env.ambient_light_energy = 0.45
	env.tonemap_mode = Environment.TONE_MAPPER_FILMIC
	world.environment = env
	add_child(world)
	var sun := DirectionalLight3D.new()
	sun.rotation_degrees = Vector3(-48, -32, 0)
	sun.light_color = Color("ffe1b7")
	sun.light_energy = 0.9
	sun.shadow_enabled = true
	sun.directional_shadow_max_distance = 100
	add_child(sun)
	camera.position = Vector3(0, 11, 21)
	camera.fov = 58
	camera.far = 450
	add_child(camera)
	camera.look_at(Vector3(0, 1.4, -23))
	camera.current = true

func build_road() -> void:
	var asphalt := material("asphalt", Color("263943"))
	var steel := material("steel", Color("667982"))
	var curb := material("curb", Color("172834"))
	var amber := material("amber", Color("ffaf50"), 0.8)
	var cyan := material("cyan", Color("53d4df"), 0.6)
	var marking := material("marking", Color("b3c0b9"))
	for i in range(-2, 61):
		var chunk := Node3D.new()
		road.add_child(chunk)
		chunk.position.z = -i * 8.0
		scenery.append(chunk)
		box(chunk, Vector3(0, -0.25, 0), Vector3(24.6, 0.5, 8), asphalt)
		for side in [-1, 1]:
			box(chunk, Vector3(side * 24, -0.55, 0), Vector3(23, 0.4, 8), material("platform", Color("33464f")))
			box(chunk, Vector3(side * 14.5, -0.32, 3.8), Vector3(3, 0.035, 0.06), steel)
		box(chunk, Vector3(0, 0.005, 3.95), Vector3(24.4, 0.02, 0.05), curb)
		for side in [-1, 1]:
			box(chunk, Vector3(side * 12.65, 0.1, 0), Vector3(0.65, 0.3, 8), steel)
			box(chunk, Vector3(side * 12.3, 0.28, 0), Vector3(0.08, 0.06, 7.8), cyan)
			box(chunk, Vector3(side * 12.9, 1.3, 0), Vector3(0.13, 0.14, 8), steel)
			for z in [-3, 1]:
				box(chunk, Vector3(side * 12.9, 0.7, z), Vector3(0.17, 1.4, 0.17), curb)
			for x in [4.1, 8.2]:
				box(chunk, Vector3(side * x, 0.016, 0), Vector3(0.06, 0.02, 3.8), marking)
		if i >= 0 and i % 2 == 0:
			for side in [-1, 1]:
				var names := ["building-a", "building-f", "building-k", "building-p"]
				var building := model("res://assets/industrial/%s.glb" % names[(i / 2 + (1 if side == 1 else 0)) % 4], chunk,
					Vector3(side * (18.2 + (i % 3) * 2), 0, 0), 8.0 + (i % 4) * 3.5, PI if side == 1 else 0.0)
				building.name = "IndustrialBuilding"
				box(chunk, Vector3(side * 14, 3.0, 0), Vector3(0.18, 6, 0.18), steel)
				box(chunk, Vector3(side * 13.6, 6, 0), Vector3(1.2, 0.12, 0.7), amber)
		if i >= 0 and i % 4 == 1:
			model("res://assets/industrial/detail-tank.glb", chunk, Vector3(-15.2, 0, 1), 2.4)
			model("res://assets/industrial/chimney-large.glb", chunk, Vector3(16.2, 0, -2), 5.0)
	for index in range(run.obstacles.size()):
		var rect: Rect2 = run.obstacles[index]
		var chunk := Node3D.new()
		road.add_child(chunk)
		chunk.position = Vector3(rect.get_center().x / SCALE, 0, -rect.get_center().y / SCALE)
		scenery.append(chunk)
		hazard_views.append(chunk)
		if run.kinds[index] == "cargo":
			var cargo := model("res://assets/industrial/shipping-container-a.glb", chunk, Vector3.ZERO, 1.7)
			var bounds := model_bounds(cargo, cargo)
			cargo.scale.x *= (rect.size.x / SCALE) / maxf(bounds.size.x * cargo.scale.x, 0.01)
			cargo.scale.z *= (rect.size.y / SCALE) / maxf(bounds.size.z * cargo.scale.z, 0.01)
			box(chunk, Vector3(0, 0.05, 1.9), Vector3(rect.size.x / SCALE + 0.3, 0.06, 0.15), amber)
		else:
			build_hazard_model(chunk, index)
	# 终点双塔与路面引导，和三个区段的架空标识。
	for gate in [0, 150, 300, 450]:
		var arch := Node3D.new()
		road.add_child(arch)
		arch.position.z = -gate
		arch.set_meta("arch", true)
		scenery.append(arch)
		for side in [-1, 1]:
			box(arch, Vector3(side * 12.8, 3, 0), Vector3(0.6, 6, 0.7), curb)
		box(arch, Vector3(0, 6, 0), Vector3(26, 0.6, 0.8), steel)
		box(arch, Vector3(0, 5.65, 0.45), Vector3(24, 0.08, 0.08), cyan)
		var sign := Label3D.new()
		sign.text = ["01  /  出发港", "02  /  能量通道", "03  /  协同归航", "双 人 抵 达  /  FINISH"][gate / 150]
		sign.font_size = 64
		sign.pixel_size = 0.009
		sign.position = Vector3(0, 6.05, 0.48)
		sign.modulate = Color("e4f5ec")
		arch.add_child(sign)
		if gate == 450:
			box(arch, Vector3(0, 0.025, 0), Vector3(24.6, 0.04, 2), cyan)
	# 连续港区承托近景地台和远景，远景单独使用城市尺度。
	var skyline := Node3D.new()
	skyline.name = "HarborBackground"
	add_child(skyline)
	box(skyline, Vector3(0, -0.85, -180), Vector3(800, 0.7, 700), material("harbor_ground", Color("40535a"))).name = "ContinuousGround"
	for row in range(3):
		for i in range(17):
			var x := (i - 8) * 31.0 + (row % 2) * 12.0
			var z := -205.0 - row * 48.0
			var height := 15.0 + ((i * 3 + row) % 5) * 5.0
			model("res://assets/industrial/%s.glb" % ["building-k", "building-p", "building-f"][(i + row) % 3], skyline,
				Vector3(x, -0.5, z), height, 0.0, 28.0)

func build_hazard_model(chunk: Node3D, index: int) -> void:
	var rect: Rect2 = run.obstacles[index]
	var kind: String = run.kinds[index]
	var spec: Dictionary = run.hazard_specs[index]
	var bottom: float = spec.bottom / SCALE
	var height: float = (run.obstacle_heights[index] - spec.bottom) / SCALE
	var mat := material("hazard_%d" % index, Color("fa6545"), 0.5)
	if kind in ["scanner", "fly_body"]:
		mat.albedo_color = Color("dd69ef")
	var volume := box(chunk, Vector3(0, bottom + height / 2, 0), Vector3(rect.size.x / SCALE, height, rect.size.y / SCALE), mat)
	volume.name = "DangerVolume"
	if kind == "rail":
		box(chunk, Vector3(0, height - 0.08, 0), Vector3(rect.size.x / SCALE, 0.16, rect.size.y / SCALE), material("rail_stripe", Color("ffe4a1")))
	if kind.begins_with("fly_"):
		# 前灯和推进器位于危险包围盒内部，不扩大视觉危险范围。
		box(volume, Vector3(0, 0, rect.size.y / SCALE / 2 + 0.001), Vector3(rect.size.x / SCALE * 0.7, height * 0.15, 0.02), material("flight_light", Color("ffc15c"), 0.8))
		var route := box(chunk, Vector3(-8, 0.025, 0), Vector3(16, 0.02, 0.08), material("flight_route", Color("ffc55b"), 0.7))
		route.name = "FlightRoute"
	if kind in ["spikes", "active_spikes"]:
		var envelope := material("spike_envelope_%d" % index, Color(0.95, 0.3, 0.15, 0.12))
		envelope.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		volume.material_override = envelope
		for x in range(8):
			var spike := MeshInstance3D.new()
			var cone := CylinderMesh.new()
			cone.top_radius = 0
			cone.bottom_radius = 0.24
			cone.height = height
			spike.mesh = cone
			spike.material_override = mat
			spike.position = Vector3(-rect.size.x / SCALE / 2 + 0.25 + x * 0.5, height / 2, 0)
			chunk.add_child(spike)
			spike.set_meta("spike", true)
	var footprint := box(chunk, Vector3(0, 0.02, 0), Vector3(rect.size.x / SCALE, 0.025, rect.size.y / SCALE), material("warning_%d" % index, Color("ffca60"), 0.5))
	footprint.name = "WarningFootprint"
	var sign := Label3D.new()
	sign.name = "WarningLabel"
	sign.text = Run.hazard_name(kind)
	sign.position = Vector3(0, maxf(1.5, bottom + height + 0.4), 0)
	sign.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	sign.font_size = 28
	sign.pixel_size = 0.012
	chunk.add_child(sign)

func build_robots() -> void:
	for index in range(2):
		var robot := Node3D.new()
		add_child(robot)
		robots.append(robot)
		var character := model("res://assets/mechs/%s.gltf" % ["George", "Leela"][index], robot, Vector3.ZERO, 2.9, PI)
		register_animation(character)
		# 识别灯保持两人辨识度；阴影固定在地面，角色独立腾空。
		var accent := material("robot_%d" % index, Color("57dbea") if index == 0 else Color("ffb95e"), 0.65)
		box(robot, Vector3(0, 0.16, 0.7), Vector3(1.25, 0.07, 0.06), accent)
		var shadow := MeshInstance3D.new()
		var disk := CylinderMesh.new()
		disk.top_radius = 0.9
		disk.bottom_radius = 0.9
		disk.height = 0.01
		shadow.mesh = disk
		var shadow_mat := material("contact_shadow_%d" % index, Color(0.015, 0.025, 0.035, 0.4))
		shadow_mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
		shadow.material_override = shadow_mat
		shadow.cast_shadow = GeometryInstance3D.SHADOW_CASTING_SETTING_OFF
		add_child(shadow)
		shadows.append(shadow)
		var tag := Label3D.new()
		tag.text = "01" if index == 0 else "02"
		tag.position = Vector3(0, 3.5, 0)
		tag.billboard = BaseMaterial3D.BILLBOARD_ENABLED
		tag.font_size = 40
		tag.pixel_size = 0.012
		tag.modulate = accent.albedo_color
		robot.add_child(tag)
	cable.mesh = BoxMesh.new()
	cable_material = material("cable", Color("60e4ea"), 1.0)
	cable_material.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	cable.material_override = cable_material
	add_child(cable)

func label(text: String, size: int, color: Color = Color("e3eee9")) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", color)
	return l

func build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)
	var root := Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	layer.add_child(root)
	var top := PanelContainer.new()
	top.position = Vector2(28, 22)
	top.size = Vector2(1224, 82)
	root.add_child(top)
	var style := StyleBoxFlat.new()
	style.bg_color = Color(0.035, 0.075, 0.1, 0.92)
	style.border_color = Color("385360")
	style.set_border_width_all(1)
	style.set_corner_radius_all(12)
	style.content_margin_left = 24
	style.content_margin_right = 24
	style.content_margin_top = 12
	style.content_margin_bottom = 12
	top.add_theme_stylebox_override("panel", style)
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 32)
	top.add_child(row)
	row.add_child(label("共 生 连 线  /  归航", 23))
	hud = label("", 18, Color("68dce3"))
	hud.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	row.add_child(hud)
	distance_label = label("", 18, Color("ffc175"))
	row.add_child(distance_label)
	progress_bar = ColorRect.new()
	progress_bar.position = Vector2(52, 89)
	progress_bar.size = Vector2(1176, 4)
	progress_bar.color = Color("2b424f")
	progress_bar.mouse_filter = Control.MOUSE_FILTER_IGNORE
	progress_fill = ColorRect.new()
	progress_fill.color = Color("5fcdd5")
	progress_fill.size = Vector2(0, 4)
	progress_fill.mouse_filter = Control.MOUSE_FILTER_IGNORE
	progress_bar.add_child(progress_fill)
	root.add_child(progress_bar)
	var bottom := label("01：WASD 移动 / 空格跳跃     ·     02：方向键移动 / 回车跳跃     ·     Esc 暂停     ·     R 重试", 17)
	bottom.position = Vector2(40, 677)
	root.add_child(bottom)
	panel = PanelContainer.new()
	panel.position = Vector2(355, 175)
	panel.size = Vector2(570, 390)
	panel.add_theme_stylebox_override("panel", style)
	root.add_child(panel)
	var column := VBoxContainer.new()
	column.add_theme_constant_override("separation", 20)
	panel.add_child(column)
	column.add_child(label("ROAD  /  01—03", 16, Color("63dbe4")))
	title = label("共生归航", 40)
	column.add_child(title)
	subtitle = label("", 19)
	subtitle.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	subtitle.custom_minimum_size = Vector2(510, 110)
	column.add_child(subtitle)
	primary = Button.new()
	primary.focus_mode = Control.FOCUS_NONE
	primary.custom_minimum_size.y = 48
	primary.add_theme_font_size_override("font_size", 21)
	primary.pressed.connect(primary_action)
	column.add_child(primary)

func clear_controls() -> void:
	blocked_keys.assign(MOVE_KEYS)
	run.reset_input()

func key_down(key: int) -> bool:
	if blocked_keys.has(key):
		if not Input.is_physical_key_pressed(key):
			blocked_keys.erase(key)
		return false
	return Input.is_physical_key_pressed(key)

func primary_action() -> void:
	if run.state == "paused":
		run.pause()
	else:
		run.retry(run.state == "failed")
	clear_controls()
	update_ui()

func _unhandled_key_input(event: InputEvent) -> void:
	if not event.is_pressed() or event.is_echo():
		return
	if event.keycode == KEY_ESCAPE:
		run.pause()
		clear_controls()
	elif event.keycode == KEY_R:
		run.retry(run.state == "failed")
		clear_controls()
	elif event.keycode == KEY_ENTER or event.keycode == KEY_SPACE:
		if run.state != "running":
			primary_action()
	update_ui()

func _physics_process(delta: float) -> void:
	if capture_mode:
		return
	var first := Vector2(float(key_down(KEY_D)) - float(key_down(KEY_A)), float(key_down(KEY_W)) - float(key_down(KEY_S)))
	var second := Vector2(float(key_down(KEY_RIGHT)) - float(key_down(KEY_LEFT)), float(key_down(KEY_UP)) - float(key_down(KEY_DOWN)))
	run.step(delta, first, second, key_down(KEY_SPACE), key_down(KEY_ENTER))
	sync_view()

func sync_view() -> void:
	var forward: float = run.distance / SCALE
	road.position.z = forward
	for chunk in scenery:
		chunk.visible = chunk.position.z + forward > -180 and chunk.position.z + forward < 22
		if chunk.has_meta("arch"):
			chunk.visible = chunk.position.z + forward < -12 and chunk.position.z + forward > -180
	for index in range(hazard_views.size()):
		var view := hazard_views[index]
		var sample: Dictionary = run.hazard_sample(index, run.elapsed)
		var rect: Rect2 = sample.rect
		view.position = Vector3(rect.get_center().x / SCALE, 0, -rect.get_center().y / SCALE)
		if run.kinds[index] == "cargo": continue
		var volume: MeshInstance3D = view.get_node("DangerVolume")
		volume.visible = sample.active
		volume.position.y = (sample.bottom + sample.top) / SCALE / 2
		volume.mesh.size.y = maxf(0.001, (sample.top - sample.bottom) / SCALE)
		for child in view.get_children():
			if child.has_meta("spike"):
				child.visible = sample.active
				child.scale.y = maxf(0.001, sample.top / run.obstacle_heights[index])
				child.position.y = sample.top / SCALE / 2
		var footprint: MeshInstance3D = view.get_node("WarningFootprint")
		footprint.material_override.albedo_color = Color("ffcb55") if sample.warning else (Color("e9553a") if sample.active else Color("51cdb6"))
		var sign: Label3D = view.get_node("WarningLabel")
		sign.text = ("预警 · " if sample.warning else ("危险 · " if sample.active else "安全时窗 · ")) + Run.hazard_name(run.kinds[index])
		if run.kinds[index].begins_with("fly_"):
			view.get_node("FlightRoute").visible = sample.warning
			footprint.visible = sample.active or sample.warning
			sign.visible = sample.active or sample.warning
	for i in range(2):
		var p: Vector2 = run.a.position if i == 0 else run.b.position
		robots[i].position = Vector3(p.x / SCALE, run.heights[i] / SCALE, -p.y / SCALE + forward)
		# 小角度倾斜反馈四向输入；镜头保持不变，松开后回正。
		robots[i].rotation.z = -run.move_directions[i].x * 0.06 if run.state == "running" else 0.0
		robots[i].rotation.x = run.move_directions[i].y * 0.035 if run.state == "running" else 0.0
		shadows[i].position = Vector3(p.x / SCALE, 0.018, -p.y / SCALE + forward)
		shadows[i].scale = Vector3.ONE * (1.0 - run.heights[i] / 100.0 + run.land_time[i] * 1.2)
		if i < animation_players.size():
			var player := animation_players[i]
			if run.state == "paused":
				player.speed_scale = 0
			else:
				player.speed_scale = 1
				if run.state == "failed":
					if not failed_animation_started[i]:
						play_action(player, "HitRecieve_1")
						failed_animation_started[i] = true
				else:
					failed_animation_started[i] = false
					play_action(player, "Jump" if run.heights[i] > 0 else ("Run" if run.state == "running" else "Idle"))
					# 动画与物理抛物线同步；不让 Jump 自带位移改变碰撞中心。
					if run.heights[i] > 0:
						player.seek(clampf((Run.JUMP_SPEED - run.vertical_speed[i]) / Run.GRAVITY / (2 * Run.JUMP_SPEED / Run.GRAVITY), 0, 1) * player.current_animation_length, true)
					elif run.actions[i] == "Land" and last_actions[i] != "Land":
						player.seek(0, true)
			last_actions[i] = run.actions[i]
	var start := robots[0].position + Vector3(0, 1.4, 0)
	var end := robots[1].position + Vector3(0, 1.4, 0)
	var offset := end - start
	cable.position = (start + end) * 0.5
	cable.mesh.size = Vector3(offset.length(), 0.085, 0.085)
	cable.quaternion = Quaternion(Vector3.RIGHT, offset.normalized()) if offset.length() > 0.001 else Quaternion.IDENTITY
	var taut: bool = run.a.position.distance_to(run.b.position) > Run.Motion.LIMIT * 0.85
	cable_material.albedo_color = Color("ffc06b") if taut else Color("60e4ea")
	cable_material.emission = cable_material.albedo_color
	update_ui()

func update_ui() -> void:
	if not is_instance_valid(hud):
		return
	hud.text = "%s  ·  本地双人" % ["01 出发港", "02 能量通道", "03 协同归航"][run.section()]
	distance_label.text = "连线 %.1f / 11 m   ·   %.0f / 450 m" % [run.a.position.distance_to(run.b.position) / SCALE, run.progress() / SCALE]
	progress_fill.size.x = run.progress() / Run.FINISH * 1176
	panel.visible = run.state != "running"
	match run.state:
		"start":
			title.text = "共生归航"
			subtitle.text = "01：WASD / 空格；02：方向键 / 回车。\n低栏、地刺和低位飞行物可跳或绕行。\n高货箱及身体高度/高大飞行物须四向避让。\n扫描束与活动地刺：黄色预警，红色危险，绿色安全时窗。"
			primary.text = "开始归航  /  Enter"
		"paused":
			title.text = "归航已暂停"
			subtitle.text = "道路、跳跃与计时已冻结。\n01：WASD / 空格；02：方向键 / 回车。\n恢复后请松开旧按键再按下。\n连线拉紧时金色提示，请向队友靠近。"
			primary.text = "继续归航  /  Esc"
		"failed":
			title.text = "连接中断"
			subtitle.text = run.reason + "\n已前进 %.0f 米。\n两人协调选择安全走廊，保持地面连接距离。" % (run.progress() / SCALE)
			primary.text = "两人共同重试  /  R"
		"finished":
			title.text = "共同抵达"
			subtitle.text = "三段道路已完成，连接始终保持。\n归航用时 %.1f 秒 · 共同重试 %d 次\n感谢协同，欢迎再次出发。" % [run.elapsed, run.failures]
			primary.text = "再次归航  /  Enter"
